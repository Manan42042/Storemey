﻿(function () {
    angular.module('app').controller('app.views.storeCityMaster', [
        '$scope', '$state', '$stateParams', 'abp.services.app.storeCityMaster',
        function ($scope, $state, $stateParams, _thisServices) {

            $.validator.addMethod("regx", function (value, element, regexpr) {
                return regexpr.test(value);
            }, "Please enter a valid pasword.");

            $scope.validationOptions = {
                rules: {
                    cityName: {
                        required: true,
                    },
                    zipcode: {
                        required: true,
                    }

                }
            };

            var stateobj = $stateParams.SearchDto;
            if ($stateParams.SearchDto !== undefined && $stateParams.SearchDto !== null && $stateParams.SearchDto !== '') {
                $scope.Id = stateobj.tempID;
            }
            else {
                $stateParams.SearchDto = null;
            }

            var GetstoreCityMasterInputDto = {
                Id: 0
            };

            $scope.GetstoreCityMasterOutputDto = {};

            function getstoreCityMaster(Id) {
                GetstoreCityMasterInputDto.Id = Id;
                _thisServices.getById(GetstoreCityMasterInputDto)
                    .then(function (result) {
                        $scope.GetstoreCityMasterOutputDto = result.data;

                    });
            }
            if ($scope.Id !== 0) {
                getstoreCityMaster($scope.Id);
            }
            else {
                getstoreCityMaster($scope.Id);
            }



            $scope.saveAddEdit = function () {

                var $loginForm = $('#frmCountry');
                if (!$loginForm.valid()) {
                    return;
                }
                debugger;
                if ($scope.GetstoreCityMasterOutputDto.id === undefined || $scope.GetstoreCityMasterOutputDto.id === 0) {
                    _thisServices.create($scope.GetstoreCityMasterOutputDto)
                        .then(function () {

                            abp.notify.success("Saved Successfully.");
                            $state.go('storeCityMaster', { SearchDto: $stateParams.SearchDto });

                        });
                }
                else {
                    _thisServices.update($scope.GetstoreCityMasterOutputDto)
                        .then(function () {

                            abp.notify.success("Updated Successfully.");
                            $state.go('storeCityMaster', { SearchDto: $stateParams.SearchDto });

                        });
                }
            };


            //$scope.saveAddEdit = function () {
            //    $state.go('storeCityMaster');
            //};

            $scope.cancelAddEdit = function () { window.scrollTo(0, 0);
                $state.go('storeCityMaster', { SearchDto: $stateParams.SearchDto });
            };
        }
    ]);
})();