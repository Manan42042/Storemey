﻿(function () {
    var controllerId = 'app.views.layout.sidebarNav';
    angular.module('app').controller(controllerId, [
        '$rootScope', '$state', 'appSession',
        function ($rootScope, $state, appSession) {
            var vm = this;

            if (vm.parentIndex === undefined) {
                vm.parentIndex = 0;
            }
            vm.Index = 20;
            vm.menuItems = [
                //createMenuItem(0, "Administration Department", "", "", "", true, [
                //    createMenuItem(1, "Master Countries", "Pages.mastercountries", "mastercountries", "mastercountries", false),
                //    createMenuItem(2, "Master Plans", "Pages.masterplans", "masterplans", "masterplans", false),
                //    createMenuItem(3, "Master Plan Services", "Pages.mastermlanservices", "masterplanservices", "masterplanservices", false),

                //]),
                createMenuItem(1000, "Home", "", "Home", "javascript:void()", true, [
                    createMenuItem(20, "Dashboard", "Pages.dashboard", "icon-dashboard", "home", false),
                ]),



                createMenuItem(1001, "POS and sale history", "", "", "", true, [
                    createMenuItem(120, "Point of sale", "", "icon-pos", "pos", false, [
                    ]),
                    createMenuItem(124, "Cash register", "Pages.CashRegister", "icon-cash-register", "CashRegister", false),

                    createMenuItem(160, "Sale history", "", "icon-sale-history", "pos", false, [
                        createMenuItem(121, "Complete sales", "Pages.storeCountryMaste", "icon-pos", "CompleteSalesOrders", false),
                        createMenuItem(123, "Incomplete sales", "Pages.storeStateMaste", "icon-pos", "UnfinishedOrders", false),
                    ]),

                ]),

                //createMenuItem(1001, "Sales", "", "", "", true, [
                    
                //]),



                createMenuItem(1001, "Features", "", "", "", true, [

                    createMenuItem(1003, "Product", "", "icon-product", "javascript:void()", true, [
                        createMenuItem(40, "Tags", "Pages.storeTags", "storeTags", "storeTags", false),
                        createMenuItem(41, "Brands", "Pages.storeBrands", "storeBrands", "storeBrands", false),
                        createMenuItem(42, "Categories", "Pages.storeCategories", "storeCategories", "storeCategories", false),
                        createMenuItem(43, "Suppliers", "Pages.storeSuppliers", "storeSuppliers", "storeSuppliers", false),
                        createMenuItem(44, "Inventory", "Pages.storeInventory", "storeInventory", "storeInventory", false),
                        createMenuItem(45, "Products", "Pages.storeProducts", "storeProducts", "storeProducts", false),
                    ]),

                    createMenuItem(1004, "Customers", "", "icon-customer", "javascript:void()", true, [
                        createMenuItem(60, "Customer Group", "Pages.storeCustomerGroup", "storeCustomerGroup", "storeCustomerGroup", false),
                        createMenuItem(61, "Customers", "Pages.storeCustomers", "storeCustomers", "storeCustomers", false),
                    ]),

                    createMenuItem(1005, "Store settings", "", "icon-system-setup", "javascript:void()", true, [
                        createMenuItem(81, "Sale Tax", "Pages.storeTax", "storeTax", "storeTax", false),
                        createMenuItem(82, "Tax Group", "Pages.TaxGroup", "Tax Group", "storeTaxGroups", false),
                        createMenuItem(83, "Payment Types", "Pages.storePaymentTypes", "storePaymentTypes", "storePaymentTypes", false),
                        createMenuItem(84, "Outlet and Register", "Pages.storeOutletAndRegister", "storeOutletAndRegister", "storeOutletAndRegister", false),
                        createMenuItem(85, "Receipt Templates", "Pages.storeReceiptTemplates", "storeReceiptTemplates", "storeReceiptTemplates", false),
                        createMenuItem(86, "Users", "Pages.storeUsers", "Users", "storeUsers", false),
                    ]),

                    createMenuItem(1006, "Masters", "", "icon-basic-setup", "javascript:void()", true, [
                        createMenuItem(100, "Country Master", "Pages.storeCountryMaster", "storeCountryMaster", "storeCountryMaster", false),
                        createMenuItem(101, "State Master", "Pages.storeStateMaster", "storeStateMaster", "storeStateMaster", false),
                        createMenuItem(102, "City Master", "Pages.storeCityMaster", "storeCityMaster", "storeCityMaster", false),
                        createMenuItem(103, "Currancies", "Pages.storecurrencies", "storecurrencies", "storecurrencies", false),
                        createMenuItem(104, "TimeZones", "Pages.storeTimeZones", "storeTimeZones", "storeTimeZones", false),
                    ]),

                ]),







                //createMenuItem(0, "Sales Orders Transactions", "", "", "", true, [
                //    createMenuItem(1103, "Comming Soon", "Comming Soon", "icon-comming-soon", "Comming Soon", false),
                //]),

                createMenuItem(0, "My ecommerce", "", "", "", true, [
                    //createMenuItem(1101, "Comming Soon", "Comming Soon", "icon-comming-soon", "Comming Soon", false),
                    createMenuItem(1003, "Ecommerce", "", "icon-ecommarce", "javascript:void()", true, [
                        createMenuItem(161, "Header Menu Management", "Pages.storeTags", "storeTags", "storeTags", false),
                        createMenuItem(162, "Footer Management", "Pages.storeBrands", "storeBrands", "storeBrands", false),
                        createMenuItem(163, "File Management", "Pages.storeCategories", "storeCategories", "storeCategories", false),
                        createMenuItem(164, "Email Template", "Pages.storeSuppliers", "storeSuppliers", "storeSuppliers", false),
                        createMenuItem(165, "Page Manager", "Pages.storeInventory", "storeInventory", "storeInventory", false),
                        createMenuItem(166, "seo management", "Pages.storeProducts", "storeProducts", "storeProducts", false),
                        createMenuItem(167, "Advertisement Management", "Pages.storeProducts", "storeProducts", "storeProducts", false),
                        createMenuItem(168, "Sale Orders", "Pages.storeProducts", "storeProducts", "storeProducts", false),
                        createMenuItem(169, "Drop Order", "Pages.storeProducts", "storeProducts", "storeProducts", false),
                    ]),
                ]),


           


                createMenuItem(0, "Integration", "", "", "", true, [
                    createMenuItem(1108, "Third party integration", "", "icon-third-party", "javascript:void()", true, [
                        createMenuItem(151, "XERO", "Pages.XERO", "XERO", "XERO", false),
                        createMenuItem(152, "SHOPIFY", "Pages.SHOPIFY", "SHOPIFY", "SHOPIFY", false),
                        createMenuItem(153, "QUICKBOOK", "Pages.QUICKBOOK", "QUICKBOOK", "QUICKBOOK", false),
                        createMenuItem(154, "BIG COMMERCE", "Pages.BigCOMMERCE", "BigCOMMERCE", "BigCOMMERCE", false),
                    ]),
                ]),

                createMenuItem(0, "Reports", "", "", "", true, [
                    createMenuItem(1107, "Advance reports", "", "icon-report", "javascript:void()", true, [

                        createMenuItem(151, "Sales", "Pages.Sale", "Sales", "Sales", false),
                        createMenuItem(152, "Customers", "Pages.Customer", "Customer", "Customer", false),
                        createMenuItem(153, "Inventory", "Pages.Inventory", "Inventory", "Inventory", false),
                        createMenuItem(154, "Register Closer", "Pages.RegisterCloser", "RegisterCloser", "RegisterCloser", false),
                        createMenuItem(155, "Tax", "Pages.Tax", "Tax", "Tax", false),
                        createMenuItem(156, "Products", "Pages.Product", "Product", "Product", false),
                    ]),

                ]),

                createMenuItem(0, "Bug History", "", "", "", true, [
                    createMenuItem(1104, "Bug tracker", "Pages.storeGeneralSettings", "icon-bug-tracker", "storeGeneralSettings", false),
                ]),
                createMenuItem(0, "Settings", "", "", "", true, [
                    createMenuItem(141, "General settings", "Pages.storeGeneralSettings", "icon-general-setting", "storeGeneralSettings", false),
                ]),
            ];


            vm.showMenuItem = function (menuItem) {
                if (menuItem.permissionName) {
                    return abp.auth.isGranted(menuItem.permissionName);
                }
                return true;
            }

            function createMenuItem(index, name, permissionName, icon, route, isTitle, childItems) {
                return {
                    index: index,
                    name: name,
                    permissionName: permissionName,
                    icon: icon,
                    route: route,
                    items: childItems,
                    isTitle: isTitle
                };
            }
            vm.ActiveCurrentMenu = function (index, route) {
                if (route !== 'javascript:void()') {
                    vm.Index = index;
                    $state.go(route);
                }
            }
        }
    ]);
})();