﻿(function () {
    angular.module('app').controller('app.views.storeStateMaster', [
        '$scope', '$state', '$stateParams', 'abp.services.app.storeStateMaster',
        function ($scope, $state, $stateParams, _thisServices) {

            $.validator.addMethod("regx", function (value, element, regexpr) {
                return regexpr.test(value);
            }, "Please enter a valid pasword.");

            $scope.validationOptions = {
                rules: {
                    stateName: {
                        required: true,
                    }
                }
            };

            var stateobj = $stateParams.SearchDto;
            if ($stateParams.SearchDto !== undefined && $stateParams.SearchDto !== null && $stateParams.SearchDto !== '') {
                $scope.Id = stateobj.tempID;
            }
            else {
                $stateParams.SearchDto = null;
            }

            var GetstoreStateMasterInputDto = {
                Id: 0
            };

            $scope.GetstoreStateMasterOutputDto = {};

            function getstoreStateMaster(Id) {
                GetstoreStateMasterInputDto.Id = Id;
                _thisServices.getById(GetstoreStateMasterInputDto)
                    .then(function (result) {
                        $scope.GetstoreStateMasterOutputDto = result.data;

                    });
            }
            if ($scope.Id !== 0) {
                getstoreStateMaster($scope.Id);
            }
            else {
                getstoreStateMaster($scope.Id);
            }



            $scope.saveAddEdit = function () {

                var $loginForm = $('#frmCountry');
                if (!$loginForm.valid()) {
                    return;
                }
                debugger;
                if ($scope.GetstoreStateMasterOutputDto.id === undefined || $scope.GetstoreStateMasterOutputDto.id === 0) {
                    _thisServices.create($scope.GetstoreStateMasterOutputDto)
                        .then(function () {

                            abp.notify.success("Saved Successfully.");
                            $state.go('storeStateMaster', { SearchDto: $stateParams.SearchDto });

                        });
                }
                else {
                    _thisServices.update($scope.GetstoreStateMasterOutputDto)
                        .then(function () {

                            abp.notify.success("Updated Successfully.");
                            $state.go('storeStateMaster', { SearchDto: $stateParams.SearchDto });

                        });
                }
            };


            //$scope.saveAddEdit = function () {
            //    $state.go('storeStateMaster');
            //};

            $scope.cancelAddEdit = function () { window.scrollTo(0, 0);
                $state.go('storeStateMaster', { SearchDto: $stateParams.SearchDto });
            };
        }
    ]);
})();