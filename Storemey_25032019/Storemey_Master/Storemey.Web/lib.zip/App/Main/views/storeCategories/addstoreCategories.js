﻿(function () {
    angular.module('app').controller('app.views.storeCategories', [
        '$scope', '$state', '$stateParams', 'abp.services.app.storeCategories',
        function ($scope, $state, $stateParams, _thisServices) {

            $.validator.addMethod("regx", function (value, element, regexpr) {
                return regexpr.test(value);
            }, "Please enter a valid pasword.");

            $scope.validationOptions = {
                rules: {
                    categoryName: {
                        required: true,
                    }
                }
            };

            var stateobj = $stateParams.SearchDto;
            if ($stateParams.SearchDto !== undefined && $stateParams.SearchDto !== null && $stateParams.SearchDto !== '') {
                $scope.Id = stateobj.tempID;
            }
            else {
                $stateParams.SearchDto = null;
            }

            var GetstoreCategoriesInputDto = {
                Id: 0
            };

            $scope.GetstoreCategoriesOutputDto = {};

            function getstoreCategories(Id) {
                GetstoreCategoriesInputDto.Id = Id;
                _thisServices.getById(GetstoreCategoriesInputDto)
                    .then(function (result) {
                        $scope.GetstoreCategoriesOutputDto = result.data;

                    });
            }
            if ($scope.Id !== 0) {
                getstoreCategories($scope.Id);
            }
            else {
                getstoreCategories($scope.Id);
            }



            $scope.saveAddEdit = function () {

                var $loginForm = $('#frmCountry');
                if (!$loginForm.valid()) {
                    return;
                }
                debugger;
                if ($scope.GetstoreCategoriesOutputDto.id === undefined || $scope.GetstoreCategoriesOutputDto.id === 0) {
                    _thisServices.create($scope.GetstoreCategoriesOutputDto)
                        .then(function () {

                            abp.notify.success("Saved Successfully.");
                            $state.go('storeCategories', { SearchDto: $stateParams.SearchDto });

                        });
                }
                else {
                    _thisServices.update($scope.GetstoreCategoriesOutputDto)
                        .then(function () {

                            abp.notify.success("Updated Successfully.");
                            $state.go('storeCategories', { SearchDto: $stateParams.SearchDto });

                        });
                }
            };


            //$scope.saveAddEdit = function () {
            //    $state.go('storeCategories');
            //};

            $scope.cancelAddEdit = function () { window.scrollTo(0, 0);
                $state.go('storeCategories', { SearchDto: $stateParams.SearchDto });
            };
        }
    ]);
})();