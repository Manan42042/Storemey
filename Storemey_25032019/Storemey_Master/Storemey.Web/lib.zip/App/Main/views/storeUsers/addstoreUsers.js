﻿(function () {
    angular.module('app').controller('app.views.storeUsers', [
        '$scope', '$state', '$stateParams', 'abp.services.app.storeUsers',
        function ($scope, $state, $stateParams, _thisServices) {

            $.validator.addMethod("regx", function (value, element, regexpr) {
                return regexpr.test(value);
            }, "Please enter a valid pasword.");

            $scope.validationOptions = {
                rules: {
                    firstName: {
                        required: true,
                    },
                    lastName: {
                        required: true,
                    },
                    phoneNumber: {
                        required: true,
                    },
                    userName: {
                        required: true,
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        //change regexp to suit your needs
                        regx: /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/,
                    }
                }
            }

            var stateobj = $stateParams.SearchDto;
            if ($stateParams.SearchDto !== undefined && $stateParams.SearchDto !== null && $stateParams.SearchDto !== '') {
                $scope.Id = stateobj.tempID;
            }
            else {
                $stateParams.SearchDto = null;
            }

            var GetstoreUsersInputDto = {
                Id: 0
            };

            $scope.GetstoreUsersOutputDto = {};

            function getstoreUsers(Id) {
                GetstoreUsersInputDto.Id = Id;
                _thisServices.getById(GetstoreUsersInputDto)
                    .then(function (result) {
                        $scope.GetstoreUsersOutputDto = result.data;

                    });
            }
            if ($scope.Id !== 0) {
                getstoreUsers($scope.Id);
            }
            else {
                getstoreUsers($scope.Id);
            }



            $scope.saveAddEdit = function () {

                var $loginForm = $('#frmCountry');
                if (!$loginForm.valid()) {
                    return;
                }
                debugger;
                if ($scope.GetstoreUsersOutputDto.id === undefined || $scope.GetstoreUsersOutputDto.id === 0) {
                    _thisServices.create($scope.GetstoreUsersOutputDto)
                        .then(function () {

                            abp.notify.success("Saved Successfully.");
                            $state.go('storeUsers', { SearchDto: $stateParams.SearchDto });

                        });
                }
                else {
                    _thisServices.update($scope.GetstoreUsersOutputDto)
                        .then(function () {

                            abp.notify.success("Updated Successfully.");
                            $state.go('storeUsers', { SearchDto: $stateParams.SearchDto });

                        });
                }
            };


            //$scope.saveAddEdit = function () {
            //    $state.go('storeUsers');
            //};

            $scope.cancelAddEdit = function () { window.scrollTo(0, 0);
                $state.go('storeUsers', { SearchDto: $stateParams.SearchDto });
            };
        }
    ]);
})();