'use strict';
/** 
  * controllers for GoogleMap 
  * AngularJS Directive
*/
